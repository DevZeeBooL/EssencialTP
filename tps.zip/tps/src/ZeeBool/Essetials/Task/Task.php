<?php

namespace ZeeBool\Essetials\Task;

use pocketmine\scheduler\Task as TS;
use pocketmine\Server;
use pocketmine\Player;

use ZeeBool\Essetials\Main;

class Task extends TS {
	
public $plugin;
public $player;
public $time;
public $data;
public $level;

public function __construct(Main $plugin, Player $player, $time, $data, $level){
  
  ($plugin);
  
  $this->plugin = $plugin;
  $this->player = $player;
  $this->time = $time;
  $this->data = $data;
  $this->level = $level;
  
}
      public function onRun($currentTick){
       
        $this->time--;
        
    if ($this->time == 0) {
      
  $this->plugin->getScheduler()->cancelTask($this->plugin->id[$this->player->getName()]);
  
$player->teleport(new Position($this->data["x"], $this->data["y"], $this->data["z"], $this->level));
    }
        
      }

}